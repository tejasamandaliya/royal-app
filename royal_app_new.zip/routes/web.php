<?php

use App\Http\Controllers\AuthController;
use App\Http\Middleware\checkAuthToken;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Session;

use Carbon\Carbon;


Route::get('/', function () {
    return view('welcome');
});

Route::post('/login',[AuthController::class,'Login'])->name('welcome.login');

Route::get('/authers', function () {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.Session::get('auth_token'),
            'Content-Type' => 'application/json'
        ])->get(env('API_URL').'authors');
    
        if($response->successful())
        {
            $responseData = $response->json();
            return view('authers')->with('authers',$responseData);
        }
        
})->middleware(checkAuthToken::class);


Route::get('/create-book', function () {
    $response = Http::withHeaders([
        'Authorization' => 'Bearer '.Session::get('auth_token'),
        'Content-Type' => 'application/json'
    ])->get(env('API_URL').'authors');

    if($response->successful())
    {
        $responseData = $response->json();
        return view('createbookpage')->with('authers',$responseData);
    }
    
})->middleware(checkAuthToken::class);


Route::post('/create-book', function (Request $request) {
    $input = $request->all();

    $request->validate([
        'author' => 'required',
        'title' =>'required'
    ]);
   
    $dateTime = isset($input['release_date']) ? Carbon::createFromFormat('Y-m-d\TH:i',$input['release_date']) : NULL;
    $data = [
        "author" => [
            "id" =>$input['author']
        ],
        "title" => $input['title'],
        "release_date" => isset($dateTime) ? $dateTime->format('Y-m-d\TH:i:s.v\Z') : NULL,
        "description" =>$input['description'],
        "isbn" => $input['isbn'],
        "format" => $input['format'],
        "number_of_pages" => $input['number_of_pages'],
    ];
   
    $response = Http::withHeaders([
        'Authorization' => 'Bearer '.Session::get('auth_token'),
        'Content-Type' => 'application/json'
    ])->post(env('API_URL').'books',$data);
    if($response->successful())
    {
        $responsea = Http::withHeaders([
            'Authorization' => 'Bearer '.Session::get('auth_token'),
            'Content-Type' => 'application/json'
        ])->get(env('API_URL').'authors');
    
        if($responsea->successful())
        {
            $responseData = $responsea->json();
            return view('authers')->with('authers',$responseData);
        }
    }
    
})->name('create.book')->middleware(checkAuthToken::class);



Route::get('/authers/{id}',function ($id) {
    $response = Http::withHeaders([
        'Authorization' => 'Bearer '.Session::get('auth_token'),
        'Content-Type' => 'application/json'
    ])->get(env('API_URL').'authors/'.$id);

    if($response->successful())
    {
        $responseData = $response->json();
        return view('autherpage')->with('autherdata',$responseData);
    }
});

Route::get('/auther-delete/{id}',function ($id) {
    $response = Http::withHeaders([
        'Authorization' => 'Bearer '.Session::get('auth_token'),
        'Content-Type' => 'application/json'
    ])->delete(env('API_URL').'authors/'.$id);

    if($response->successful())
    {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.Session::get('auth_token'),
            'Content-Type' => 'application/json'
        ])->get(env('API_URL').'authors');
    
        if($response->successful())
        {
            $responseData = $response->json();
            return view('authers')->with('authers',$responseData);
        }
    }
});


Route::get('/books', function () {
    $response = Http::withHeaders([
        'Authorization' => 'Bearer '.Session::get('auth_token'),
        'Content-Type' => 'application/json'
    ])->get(env('API_URL').'books');

    if($response->successful())
    {
        $responseData = $response->json();
        return view('books')->with('books',$responseData);
    }
    
})->middleware(checkAuthToken::class);


Route::get('/books/{id}',function ($id) {
    $response = Http::withHeaders([
        'Authorization' => 'Bearer '.Session::get('auth_token'),
        'Content-Type' => 'application/json'
    ])->get(env('API_URL').'books/'.$id);

    if($response->successful())
    {
        $responseData = $response->json();
        $autherId = $responseData['author']['id'];

        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.Session::get('auth_token'),
            'Content-Type' => 'application/json'
        ])->get(env('API_URL').'authors/'.$autherId);
    
        if($response->successful())
        {
            $autherData = $response->json();
            $auther_name = $autherData['first_name'] . ' '.$autherData['last_name'];
        }
        return view('bookpage',['bookdata' => $responseData,'auther_name' => $auther_name]);
    }
});

Route::get('/book-delete/{id}',function ($id) {
    $response = Http::withHeaders([
        'Authorization' => 'Bearer '.Session::get('auth_token'),
        'Content-Type' => 'application/json'
    ])->delete(env('API_URL').'books/'.$id);

    if($response->successful())
    {
        return redirect()->back();

    }
});

Route::get('/logout',function (Request $request) {

    \DB::table('royal_app_tokens')->where('token_key',Session::get('auth_token'))->delete();
    $request->session()->forget('auth_token');

    return redirect('/');

    
});



