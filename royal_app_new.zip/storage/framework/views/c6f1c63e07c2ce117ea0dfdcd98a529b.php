<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Authers</title>
</head>
<body>


    <div class="container">
      <center><h1>Auther Page</h1></center>
      <hr>
      <a href=<?php echo e(asset('authers')); ?>>Back</a>

      <?php if(count($autherdata['books']) == 0): ?>
      <a href=<?php echo e(asset('auther-delete/'.$autherdata['id'])); ?>>Delete</a>
          
      <?php endif; ?>

        <div class="raw d-flex justify-content-center">
            <div class="col-md-8">
                <b>Name</b> : <?php echo e($autherdata['first_name'] . ' '.$autherdata['last_name']); ?> <br>
                <b>Birthday</b> : <?php echo e($autherdata['birthday']); ?> <br>
                <b>Gender</b> : <?php echo e($autherdata['gender']); ?> <br>
                <b>place of birth</b> : <?php echo e($autherdata['place_of_birth']); ?> <br>
                <br>
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Release date</th>
                        <th scope="col">Description</th>
                        <th scope="col">Isbn</th>
                        <th scope="col">Format</th>
                        <th scope="col">Number of pages</th>
                        <th scope="col">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                       <?php $__empty_1 = true; $__currentLoopData = $autherdata['books']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <tr>
                          <th scope="row"><?php echo e($book['id']); ?></th>
                          <td><?php echo e($book['title']); ?></td>
                          <td><?php echo e($book['release_date']); ?></td>
                          <td><?php echo e($book['description']); ?></td>
                          <td><?php echo e($book['isbn']); ?></td>
                          <td><?php echo e($book['format']); ?></td>
                          <td><?php echo e($book['number_of_pages']); ?></td>
                          <td><a href=<?php echo e(url('book-delete/'.$book['id'])); ?>>Delete</a></td>
                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                        <th>No data found</th>
                      </tr>
                       <?php endif; ?> 
                    </tbody>
                  </table>
            </div>
        </div>
    </div>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH /home/dev/Sites/laravel/royal_app_new/resources/views/autherpage.blade.php ENDPATH**/ ?>