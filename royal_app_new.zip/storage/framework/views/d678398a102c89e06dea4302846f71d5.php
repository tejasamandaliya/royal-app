<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Books</title>
</head>
<body>


    <div class="container">
      <center><h1>books</h1></center>
      <hr>
      <a href=<?php echo e(asset('authers')); ?>>Back</a>
        <div class="raw d-flex justify-content-center">
            <div class="col-md-8">
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">title</th>
                        <th scope="col">release_date</th>
                        <th scope="col">isbn</th>
                        <th scope="col">format</th>
                        <th scope="col">number_of_pages</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                       <?php $__empty_1 = true; $__currentLoopData = $books['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <tr>
                          <th scope="row"><?php echo e($book['id']); ?></th>
                          <td><?php echo e($book['title']); ?></td>
                          <td><?php echo e($book['release_date']); ?></td>
                          <td><?php echo e($book['isbn']); ?></td>
                          <td><?php echo e($book['format']); ?></td>
                          <td><?php echo e($book['number_of_pages']); ?></td>
                          <td><a href=<?php echo e(url('books/'.$book['id'])); ?>>View</a></td>
                          <td><a href="">Delete</a></td>
                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                        <th>No data found</th>
                      </tr>
                       <?php endif; ?> 
                    </tbody>
                  </table>
            </div>
        </div>
    </div>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH /home/dev/Sites/laravel/royal_app_new/resources/views/books.blade.php ENDPATH**/ ?>