<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Book</title>
</head>
<body>

<center><h1>Add Auther</h1></center>
<hr>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-6">
                <form method="POST" action=<?php echo e(route('create.book')); ?>>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Auther</label>
                        <select class="form-control" name="author">
                        <?php $__currentLoopData = $authers['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auther): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($auther['id']); ?>><?php echo e($auther['first_name'].' '.$auther['last_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
          
                    </div>
                    

                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Title</label>
                      <input type="text" class="form-control" name="title">
        
                    </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Release date</label>
                        <input type="datetime-local" class="form-control" name="release_date">
          
                    </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Description</label>
                        <input type="text" class="form-control" name="description">
          
                    </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">isbn</label>
                        <input type="text" class="form-control" name="isbn">
          
                    </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Format</label>
                        <input type="text" class="form-control" name="format">
          
                    </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Number of pages</label>
                        <input type="number" class="form-control" name="number_of_pages">
          
                    </div>
                   
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
            </div>
        </div>
    </div>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH /home/dev/Sites/laravel/royal_app_new/resources/views/createbookpage.blade.php ENDPATH**/ ?>