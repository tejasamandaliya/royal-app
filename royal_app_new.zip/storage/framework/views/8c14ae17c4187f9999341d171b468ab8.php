<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Authers</title>
</head>
<body>


    <div class="container">
      <center><h1>Authers</h1></center>
      <hr>Welcome, <?php echo e(session('user_name')); ?>

      <hr>
      <a href=<?php echo e(asset('books')); ?>>Books</a> <br>
      <a href=<?php echo e(asset('create-book')); ?>>Add Books</a><br>
      <a href=<?php echo e(asset('logout')); ?>>Logout</a><br>
      
        <div class="raw d-flex justify-content-center">
            <div class="col-md-8">
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Birthday</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Place Of Birth</th>
                        <th scope="col">Edit</th>
                      </tr>
                    </thead>
                    <tbody>
                       <?php $__empty_1 = true; $__currentLoopData = $authers['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auther): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <tr>
                          <th scope="row"><?php echo e($auther['id']); ?></th>
                          <td><?php echo e($auther['first_name']); ?></td>
                          <td><?php echo e($auther['last_name']); ?></td>
                          <td><?php echo e($auther['birthday']); ?></td>
                          <td><?php echo e($auther['gender']); ?></td>
                          <td><?php echo e($auther['place_of_birth']); ?></td>
                          <td><a href=<?php echo e(url('authers/'.$auther['id'])); ?>>View</a></td>

                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                        <th>No data found</th>
                      </tr>
                       <?php endif; ?> 
                    </tbody>
                  </table>
            </div>
        </div>
    </div>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH /home/dev/Sites/laravel/royal_app_new/resources/views/authers.blade.php ENDPATH**/ ?>